<?php
$siteUrl = env('APP_URL');
?>


 <link rel="stylesheet" href="<?php echo e($siteUrl); ?>public/assets/css/custom.css">
 
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('element.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="calendar-shell d-flex flex-column flex-lg-row">
        <aside class="calendar-shell__sidebar d-none d-lg-block">
            <?php echo $__env->make('element.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </aside>

        <main class="calendar-shell__body flex-grow-1">
            <?php echo $__env->yieldContent('calendar-content'); ?>
        </main>
    </div>

    <?php echo $__env->make('element.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\tirtheasy-dms\resources\views/layout/calendar.blade.php ENDPATH**/ ?>