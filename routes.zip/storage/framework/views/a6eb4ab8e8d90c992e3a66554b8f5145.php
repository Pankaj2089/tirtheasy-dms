<style>
    :root {
        --calendar-column-count: 7;
        --calendar-cell-min-width: 110px;
    }
    .cell-booked{
        display: none !important;
    }
    
    /* Room Number Dropdown Styles */
    .room-number-select-wrapper {
        position: relative;
    }
    
    .room-number-dropdown {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        z-index: 1000;
        background: white;
        border: 1px solid #ddd;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        margin-top: 2px;
    }
    
    .room-number-dropdown .list-group-item {
        cursor: pointer;
        padding: 8px 12px;
        border: none;
        border-bottom: 1px solid #eee;
    }
    
    .room-number-dropdown .list-group-item:hover {
        background-color: #f8f9fa;
    }
    
    .room-number-dropdown .list-group-item:last-child {
        border-bottom: none;
    }
    
    .selected-room-numbers .badge {
        font-size: 0.875rem;
        padding: 4px 8px;
    }
    
    .selected-room-numbers .btn-close {
        margin-left: 4px;
        opacity: 0.8;
    }
    
    .selected-room-numbers .btn-close:hover {
        opacity: 1;
    }
</style>

<?php /**PATH E:\xampp\htdocs\tirtheasy-dms\resources\views/calendar/components/calendar-styles.blade.php ENDPATH**/ ?>