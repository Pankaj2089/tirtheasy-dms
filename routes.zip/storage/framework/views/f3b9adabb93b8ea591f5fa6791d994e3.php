<footer class="mobile-footer" style="display: none;">
    <a href="#" class="footer-item">
        <!-- Home Icon -->
        <img src="<?php echo e($siteUrl); ?>public/assets/img/dashboard.svg" alt="">
        <span>Dashboard</span>
    </a>
    <a href="#" class="footer-item">
        <!-- History Icon -->
        <img src="<?php echo e($siteUrl); ?>public/assets/img/views.svg" alt="">
        <span>Stay View</span>
    </a>
    <a href="#" class="footer-item">
        <!-- Profile Icon -->
        <img src="<?php echo e($siteUrl); ?>public/assets/img/reservation.svg" alt="">
        <span>Reservation</span>
    </a>
    <a href="#" class="footer-item">
        <!-- Order Icon -->
        <img src="<?php echo e($siteUrl); ?>public/assets/img/share.svg" alt="">
        <span>Share Link</span>
    </a>
</footer><?php /**PATH E:\xampp\htdocs\tirtheasy-dms\resources\views/element/footer.blade.php ENDPATH**/ ?>