<!-- Room Rows -->
<div class="rooms-container">
    <!-- Room availability dynamically rendered here by JavaScript -->
</div>

<?php /**PATH E:\xampp\htdocs\tirtheasy-dms\resources\views/calendar/components/calendar-grid.blade.php ENDPATH**/ ?>