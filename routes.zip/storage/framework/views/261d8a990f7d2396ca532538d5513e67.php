<?php
$siteUrl = env('APP_URL');
?>

<!-- Date Header Navigation -->
<div class="date-header-wrapper">
    <div class="bg-white border-bottom py-2 fillter">
        <div class="container-fluid px-3">
            <div class="row align-items-center g-2">
                <!-- Date Selector -->
                <div class="col-12 col-md-auto d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <button class="btn btn-link text-dark px-3 py-0 cal">
                            <input type="date" id="datePicker" placeholder="04, October, 2025" class="border-0">
                        </button>
                    </div>
                    <button class="btn btn-outline-danger btn-sm text-nowrap assign-mobile"
                        data-bs-toggle="modal" data-bs-target="#assign">Assign Rooms</button>
                </div>

                <!-- Status Filters -->
                <div class="col-12 col-md filter-md">
                    <div class="d-flex flex-wrap gap-2">
                        <button class="bg-transparent">All <span class="badge bg-secondary">0</span></button>
                        <button class="bg-transparent">Vacant <span class="badge bg-secondary">0</span></button>
                        <button class="bg-transparent">Occupied <span class="badge bg-secondary">0</span></button>
                        <button class="bg-transparent">Reserved <span class="badge bg-secondary">0</span></button>
                        <button class="bg-transparent">Blocked <span class="badge bg-secondary">0</span></button>
                        <button class="bg-transparent">Due Date <span class="badge bg-secondary">0</span></button>
                    </div>
                </div>

                <!-- Property Selector & Assign Button -->
                <div class="col-12 col-md-auto">
                    <div class="d-flex gap-4">
                        <select class="form-select form-select-sm" id="hotelSelector">
                            <option value="">All Properties</option>
                            <?php if(isset($hotels) && (is_array($hotels) || is_iterable($hotels))): ?>
                                <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($hotel->id); ?>"><?php echo e($hotel->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <select class="form-select form-select-sm mobile-room"
                            style="width: 210px; display: none;" data-room-type-selector="true">
                            <option value="">All Room Types</option>
                            <?php if(isset($roomCategories) && (is_array($roomCategories) || is_iterable($roomCategories))): ?>
                                <?php $__currentLoopData = $roomCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <button class="btn btn-outline-danger btn-sm text-nowrap assign-desktop"
                            data-bs-toggle="modal" data-bs-target="#assign">Assign Rooms</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="date-header-scroll shadow-sm">
        <div class="date-header-container">
            <div class="d-flex align-items-center px-3 bg-light desktop-room">
                <select class="form-select form-select-sm" style="width: 210px;" data-room-type-selector="true">
                    <option value="">All Room Types</option>
                    <?php if(isset($roomCategories) && (is_array($roomCategories) || is_iterable($roomCategories))): ?>
                        <?php $__currentLoopData = $roomCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="d-flex align-items-center position-relative gap-2 flex-wrap flex-md-nowrap">
                <div class="btn-group btn-group-sm view-toggle d-none" role="group" aria-label="Calendar view">
                    <button type="button" class="btn btn-outline-secondary active" data-view="week" id="weekViewBtn">Week</button>
                    <button type="button" class="btn btn-outline-secondary" data-view="month" id="monthViewBtn">Month</button>
                </div>
                <button class="bg-transpaent border-0 arrow-slide left" id="prevRangeBtn">
                    <img src="<?php echo e($siteUrl); ?>public/assets/img/circle-arrow.svg" alt="">
                </button>
                <div class="date-columns flex-grow-1" id="dateColumns"></div>
                <button class="bg-transpaent border-0 arrow-slide right" id="nextRangeBtn">
                    <img src="<?php echo e($siteUrl); ?>public/assets/img/circle-arrow.svg" alt="">
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Room Type Filter & Info -->
<div class="border-bottom room-cat">
    <div class="container-fluid px-3">
        <div class="d-flex align-items-center justify-content-center flex-wrap gap-2">
            <div class="room-label-header"></div>
        </div>
    </div>
</div>

<?php /**PATH E:\xampp\htdocs\tirtheasy-dms\resources\views/calendar/components/calendar-header.blade.php ENDPATH**/ ?>