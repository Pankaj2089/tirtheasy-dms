<?php
$siteUrl = env('APP_URL');
?>

<!-- Room Availability Footer -->
<div class="availability-footer fixed-bottom border-top">
    <div class="footer-row position-relative">
        <div class="footer-label">Room Availability</div>
        <div class="footer-grid">
            <div class="footer-cell">34</div>
            <div class="footer-cell">55</div>
            <div class="footer-cell">68</div>
            <div class="footer-cell">64</div>
            <div class="footer-cell">66</div>
            <div class="footer-cell">74</div>
            <div class="footer-cell">78</div>
            <div class="footer-cell">84</div>
            <div class="footer-cell">86</div>
            <div class="footer-cell">89</div>
        </div>
        <div class="drop-one"><img src="<?php echo e($siteUrl); ?>public/assets/img/arrow.svg" alt=""></div>
    </div>
    <div id="coll-one" style="display: none;"></div>
    
    <div class="footer-row">
        <div class="footer-label">Occupancy (%)</div>
        <div class="footer-grid">
            <div class="footer-cell">72</div>
            <div class="footer-cell">46</div>
            <div class="footer-cell">35</div>
            <div class="footer-cell">39</div>
            <div class="footer-cell">23</div>
            <div class="footer-cell">16</div>
            <div class="footer-cell">13</div>
            <div class="footer-cell">11</div>
            <div class="footer-cell">07</div>
            <div class="footer-cell">03</div>
        </div>
    </div>
</div>

<!-- Selection Action Tooltip -->
<div id="selection-action-tooltip" class="selection-action-tooltip d-none">
    <div class="selection-action-title">Create for selection</div>
    <div class="selection-action-range" id="selection-action-range"></div>
    <div class="selection-action-duration" id="selection-action-duration"></div>
    <button type="button" class="selection-action-btn" data-action="reservation">
        Reservation
    </button>
    <button type="button" class="selection-action-btn" data-action="maintenance">
        Maintenance Block
    </button>
</div>

<!-- Legend -->
<div class="legend-container fixed-bottom pb-2">
    <div class="container-fluid px-3">
        <div class="d-flex flex-wrap gap-2 justify-content-end">
            <div class="legend-item">
                <span class="legend-dot" style="background: #f8d7a1;"></span>
                <span>Offline</span>
            </div>
            <div class="legend-item">
                <span class="legend-dot" style="background: #ffb3b3;"></span>
                <span>Tirtheasy</span>
            </div>
            <div class="legend-item">
                <span class="legend-dot" style="background: #dc3545;"></span>
                <span>Assign Room</span>
            </div>
            <div class="legend-item">
                <span class="legend-dot" style="background: #212529;"></span>
                <span>Maintenance</span>
            </div>
        </div>
    </div>
</div>

<?php /**PATH E:\xampp\htdocs\tirtheasy-dms\resources\views/calendar/components/calendar-footer.blade.php ENDPATH**/ ?>