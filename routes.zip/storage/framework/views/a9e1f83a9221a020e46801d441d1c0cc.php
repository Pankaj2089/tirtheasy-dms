<?php
    $checkIn = \Carbon\Carbon::parse($booking['check_in_date']);
    $checkOut = $booking['check_out_date'] ? \Carbon\Carbon::parse($booking['check_out_date']) : null;
    $checkInMonth = strtoupper($checkIn->format('M'));
    $checkInDay = $checkIn->format('d');
    $checkInTime = $checkIn->format('h:i A');
    
    if ($checkOut) {
        $checkOutMonth = strtoupper($checkOut->format('M'));
        $checkOutDay = $checkOut->format('d');
        $checkOutTime = $checkOut->format('h:i A');
    } else {
        $checkOutMonth = $checkInMonth;
        $checkOutDay = $checkInDay;
        $checkOutTime = $checkInTime;
    }
    
    $formatCurrency = function($amount) {
        return 'Rs. ' . number_format($amount, 2);
    };
    
    $reservationType = ucfirst($booking['reservation_type'] ?? 'confirmed');
    $mealPlan = 'Meal Only'; // You can customize this based on your data
?>

<div class="col-md-3 my-2 mb-3">
    <div class="reserve-box" data-booking-id="<?php echo e($booking['id']); ?>">
        <div class="box-top d-flex align-items-center justify-content-between">
            <div class="media d-flex">
                <img src="<?php echo e($siteUrl); ?>public/assets/img/cal-icon.svg" alt="">
                <div class="media-body ms-3">
                    <h5><?php echo e($booking['guest_name']); ?> 
                        <?php if($booking['payment_status'] === 'PAID' || $booking['payment_status'] === 'SUCCESS'): ?>
                            <img src="<?php echo e($siteUrl); ?>public/assets/img/tick.svg" alt="">
                        <?php endif; ?>
                    </h5>
                    <p class="mb-0"><?php echo e($booking['reservation_number']); ?></p>
                </div>
            </div>
            <button class="bg-transparent border-0"><img src="<?php echo e($siteUrl); ?>public/assets/img/box-option.svg" alt=""></button>
        </div>

        <div class="box-detail d-flex align-items-center">
            <div class="date">
                <p><?php echo e($checkInMonth); ?> <span><?php echo e($checkInDay); ?></span></p>
                <p><?php echo e($checkInTime); ?></p>
                <hr>
                <p><?php echo e($checkOutMonth); ?> <span><?php echo e($checkOutDay); ?></span></p>
                <p><?php echo e($checkOutTime); ?></p>
            </div>
            <ul>
                <li>
                    <a href="">
                        <img src="<?php echo e($siteUrl); ?>public/assets/img/night.svg" alt="">
                        <span><?php echo e($booking['nights']); ?> Night Stay</span>
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="<?php echo e($siteUrl); ?>public/assets/img/bed.svg" alt="">
                        <span><?php echo e($booking['rooms']); ?> Rooms / <?php echo e($mealPlan); ?></span>
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="<?php echo e($siteUrl); ?>public/assets/img/Family.svg" alt="">
                        <span><?php echo e($booking['adults']); ?> Adult<?php echo e($booking['adults'] != 1 ? 's' : ''); ?><?php echo e($booking['children'] > 0 ? ', ' . $booking['children'] . ' Child' . ($booking['children'] != 1 ? 'ren' : '') : ''); ?></span>
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="<?php echo e($siteUrl); ?>public/assets/img/tick.svg" alt="">
                        <span><?php echo e($reservationType); ?> Reservation</span>
                    </a>
                </li>
                <li>
                    <a href="#" class="assign-room-link <?php echo e($booking['has_room_assigned'] ? 'room-assigned' : ''); ?>" 
                       data-booking-id="<?php echo e($booking['id']); ?>" 
                       data-booking-order-id="<?php echo e($booking['order_id']); ?>" 
                       data-booking-rooms="<?php echo e($booking['rooms']); ?>">
                        <img src="<?php echo e($siteUrl); ?>public/assets/img/tick.svg" alt="">
                        <span><?php echo e($booking['has_room_assigned'] ? 'Room Assigned' : 'Assign Room'); ?></span>
                    </a>
                </li>
            </ul>
        </div>
        <div class="box-conclusion">
            <ul>
                <li class="d-flex align-items-center justify-content-between">
                    <span>Total</span>
                    <span><?php echo e($formatCurrency($booking['total'])); ?></span>
                </li>
                <li class="d-flex align-items-center justify-content-between">
                    <span>Paid</span>
                    <span><?php echo e($formatCurrency($booking['paid'])); ?></span>
                </li>
                <li class="d-flex align-items-center justify-content-between">
                    <span>Balance</span>
                    <span class="text-danger"><?php echo e($formatCurrency($booking['balance'])); ?></span>
                </li>
            </ul>
        </div>
    </div>
</div>

<?php /**PATH E:\xampp\htdocs\tirtheasy-dms\resources\views/reservation/booking-card.blade.php ENDPATH**/ ?>